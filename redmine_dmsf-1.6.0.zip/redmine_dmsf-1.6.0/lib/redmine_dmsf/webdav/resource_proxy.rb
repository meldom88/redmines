# encoding: utf-8
#
# Redmine plugin for Document Management System "Features"
#
# Copyright (C) 2012    Daniel Munn <dan.munn@munnster.co.uk>
# Copyright (C) 2011-17 Karel Pičman <karel.picman@kontron.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

require 'dav4rack'

module RedmineDmsf
  module Webdav

    # ResourceProxy
    #
    # This is more of a factory approach of an object, class determines which class to
    # instantiate based on pathing information, it then populates @resource_c with this
    # object, and proxies calls made against class to it.
    class ResourceProxy < DAV4Rack::Resource

      def initialize(*args)
        super(*args)
        pinfo = path.split('/').drop(1)
        if (pinfo.length == 0) # If this is the base_path, we're at root
          @resource_c = IndexResource.new(*args)
        elsif (pinfo.length == 1) #This is first level, and as such, project path
          @resource_c = ProjectResource.new(*args)
        else # We made it all the way to DMSF Data
          @resource_c = DmsfResource.new(*args)
        end
        @resource_c.accessor = self if @resource_c
      end

      def authenticate(username, password)
        unless username && password
          # Bugfix: Current DAV4Rack (including production) authenticate against ALL requests
          # Microsoft Web Client will not attempt any authentication (it'd seem) until it's acknowledged
          # a completed OPTIONS request. Ideally this is a flaw with the controller, however as I'm not
          # going to fork it to ensure compliance, checking the request method in the authentication
          # seems the next best step, if the request method is OPTIONS return true, controller will simply
          # call the options method within, which accesses nothing, just returns headers about dav env.
          return true if @request.request_method.downcase == 'options' && (path == '/' || path.empty?)

          # Allow anonymous OPTIONS requests from MsOffice
          return true if @request.request_method.downcase == 'options' && !@request.user_agent.nil? && @request.user_agent.downcase.include?('microsoft office')
          # Allow anonymous HEAD requests from MsOffice
          return true if @request.request_method.downcase == 'head' && !@request.user_agent.nil? && request.user_agent.downcase.include?('microsoft office')
        end
          
        return false unless username && password
        User.current = User.try_to_login(username, password)
        return User.current && !User.current.anonymous?
      end

      def supports_locking?
        true
      end

      def children
        @resource_c.children
      end

      def collection?
        @resource_c.collection?
      end

      def exist?
        @resource_c.exist?
      end

      def really_exist?
        @resource_c.really_exist?
      end

      def creation_date
        @resource_c.creation_date
      end

      def last_modified
        @resource_c.last_modified
      end
      
      def etag
        @resource_c.etag
      end

      def content_type
        @resource_c.content_type
      end

      def content_length
        @resource_c.content_length
      end

      def get(request, response)
        @resource_c.get(request, response)
      end

      def put(request, response)
        @resource_c.put(request, response)
      end

      def delete
        @resource_c.delete
      end

      def copy(dest, overwrite = false)
        @resource_c.copy(dest, overwrite)
      end

      def move(dest, overwrite = false)
        @resource_c.move(dest, overwrite)
      end

      def make_collection
        @resource_c.make_collection
      end

      def special_type
        @resource_c.special_type
      end

      def lock(args)
        @resource_c.lock(args)
      end

      def lock_check(lock_scope = nil)
        @resource_c.lock_check(lock_scope)
      end

      def unlock(token)
        @resource_c.unlock(token)
      end

      def name
        @resource_c.name
      end

      def long_name
        @resource_c.long_name
      end

      def resource
        @resource_c
      end

      def get_property(element)
        @resource_c.get_property(element)
      end

      def properties
        @resource_c.properties
      end
    end
  end
end
